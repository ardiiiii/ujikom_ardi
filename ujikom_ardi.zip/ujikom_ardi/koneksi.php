<?php
$koneksi = mysqli_connect("localhost", "root", "", "ardi_kel2_appem");


?>
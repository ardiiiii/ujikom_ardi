<?php 
// mengaktifkan session pada php
session_start();
 
// menghubungkan php dengan koneksi database
require 'koneksi.php';
 
// menangkap data yang dikirim dari form login
$user = $_POST['username'];
$pass = $_POST['password'];
 
 
// menyeleksi data user dengan username dan password yang sesuai
$login = mysqli_query($koneksi,"SELECT * FROM petugas WHERE username='$user' AND password='$pass'");
// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($login);
 
// cek apakah username dan password di temukan pada database
if($cek > 0){
 
	$data = mysqli_fetch_assoc($login);
 
	// cek jika user login sebagai admin
	if($data['level']=="admin"){
 
		// buat session login dan username
		session_start();
        $_SESSION['id_petugas']=$data['id_petugas'];
        $_SESSION['user'] = $user;
        $_SESSION['nama'] = $data['nama_petugas'];
        $_SESSION['level'] = $data['level'];

        header('location:admin/admin.php');
 
	// cek jika user login sebagai pegawai
	}else if($data['level']=="petugas"){
		// buat session login dan username
		session_start();
        $_SESSION['id_petugas']=$data['id_petugas'];
        $_SESSION['user']=$user;
        $_SESSION['nama']=$data['nama_petugas'];
        $_SESSION['level']=$data['level'];

        header('location:petugas/petugas.php');
 
	// cek jika user login sebagai pengurus
	}

	}else {
        ?>
        <script type="text/javascript">
            alert ('Username Atau Password tidak ditemukan');
        window.location="index2.php";
        </script>
        <?php
    }
    ?>